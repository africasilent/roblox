getglobal game
getfield -1 GetService
pushvalue -2
pushstring Lighting
pcall 2 1 0
pushnumber 100
setfield -2 FogStart
emptystack