getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Backpack
getglobal Instance
getfield -1 new
pushstring HopperBin
pushvalue -4
pcall 2 1 0
pushnumber 1
setfield -2 BinType
emptystack
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Backpack
getglobal Instance
getfield -1 new
pushstring HopperBin
pushvalue -4
pcall 2 1 0
pushnumber 3
setfield -2 BinType
emptystack
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Backpack
getglobal Instance
getfield -1 new
pushstring HopperBin
pushvalue -4
pcall 2 1 0
pushnumber 4
setfield -2 BinType
emptystack