while true do
wait()
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.workspace.Arrows.Arrow.ArrowPart.CFrame
end