game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Workspace["BadgeAwarder"].Platform.CFrame
wait(1)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = game.Workspace["Clothing Morph maker"]["Boy Suit 1"].Boy1.Torso.CFrame