KEY = "c" -- Select a key, the key selected will clear the room on button press (A-Z) (non-capital)
SIRMEME = true -- Set this to either true or false to enable or disable SirMeme namechanger mode
_G.WALKSPEED = 80 -- Set this to the walkspeed amount you'd like
_G.HIPHEIGHT = 8 -- What hipheight blablAblAlAALAALA
 
 
loadstring(game:HttpGet(('https://pastebin.com/raw/F5vSFHZt'),true))()