getglobal game
getfield -1 ReplicatedStorage
getfield -1 Remotes
getfield -1 SetStat
getfield -1 FireServer
pushvalue -2
pushstring Aurem
pushnumber 300
pushstring math.random() is the best thing ever
pcall 4 1 0