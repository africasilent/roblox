getglobal game
getfield -1 Players
getfield -1 YourName
getfield -1 Pstats
getfield -1 Points
getfield -1 lvl
pushnumber 50
setfield -2 Value