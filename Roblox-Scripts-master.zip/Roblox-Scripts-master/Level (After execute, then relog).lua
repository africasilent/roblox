getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Data
getfield -1 Lvl
pushnumber 1000000000
setfield -2 Value