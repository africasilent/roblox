for i,v in pairs(game.Players.LocalPlayer.PlayerGui.ScreenGui.Upgrades:GetChildren()) do
v.Value = 0
end