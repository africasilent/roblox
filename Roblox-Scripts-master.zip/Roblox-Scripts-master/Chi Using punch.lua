getglobal game
getfield -1 ReplicatedStorage
getfield -1 Remotes
getfield -1 Metitate
getfield -1 InvokeServer
pushvalue -2
pushstring haxkeraihaxxhaxker1111omgmomgethecameratellmeifuhackedthisplsIneedtoknowxDDXD
pcall 2 1 0
