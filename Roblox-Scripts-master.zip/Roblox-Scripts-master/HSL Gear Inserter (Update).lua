--High School Life Tool Inserter
--Scripted By: xXVenomouzIncXx
local Playername = "DerpyAdmins"
local GearID = 57902997
game.Players:FindFirstChild(Playername).Backpack.RemoteEvent:FireServer(game.Workspace:FindFirstChild(Playername), GearID)
--Some cool gear ID's
--116693764 - Tommy gun
--95354288 - Luger
--94233344 - Shotgun
--33383241 - Remote mine
--121946387 - Knife