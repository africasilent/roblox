getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Humanoid
pushnumber 3.5
setfield -2 HipHeight
pcall 1 0 0
settop 0