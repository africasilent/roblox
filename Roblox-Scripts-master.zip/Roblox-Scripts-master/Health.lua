getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 HealthPoint
pushstring 1000000000
setfield -2 Value
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 HealthPoint
pushstring true
setfield -2 RobloxLocked