getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Data1
getfield -1 beli
pushnumber 9999999999
setfield -2 Value