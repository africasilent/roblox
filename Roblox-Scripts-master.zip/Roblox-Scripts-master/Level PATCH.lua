getglobal game
getfield -1 Workspace
getfield -1 Core
getfield -1 AwardData
getfield -1 FireServer
pushvalue -2
pushstring Level
pushnumber 100000
pcall 3 1 0