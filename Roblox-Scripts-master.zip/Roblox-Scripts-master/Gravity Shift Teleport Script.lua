--[[  
Made By: Neglected @ V3rm
Discord: Neglected#4028

This GUI was made for Gravity Shift
No need for anyone else to make a script now
I killed the whole point of this game

Features:
Auto Win
That's it... nothing special
--]]

local GravityShiftGUI = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local One = Instance.new("TextButton")
local Two = Instance.new("TextButton")
local Three = Instance.new("TextButton")
local Four = Instance.new("TextButton")
local Five = Instance.new("TextButton")
local Six = Instance.new("TextButton")
local Seven = Instance.new("TextButton")
local Eight = Instance.new("TextButton")
local Nine = Instance.new("TextButton")
local Ten = Instance.new("TextButton")
local Eleven = Instance.new("TextButton")
local Twelve = Instance.new("TextButton")
local ThirTeen = Instance.new("TextButton")
local FourTeen = Instance.new("TextButton")
local FifTeen = Instance.new("TextButton")
local SixTeen = Instance.new("TextButton")
local SevenTeen = Instance.new("TextButton")
local EighTeen = Instance.new("TextButton")
local NineTeen = Instance.new("TextButton")
local Credits = Instance.new("TextButton")

GravityShiftGUI.Name = "GravityShiftGUI"
GravityShiftGUI.Parent = game.CoreGui
GravityShiftGUI.ResetOnSpawn = true

Frame.Name = "Frame"
Frame.Parent = GravityShiftGUI
Frame.BackgroundColor3 = Color3.fromRGB(21, 21, 21)
Frame.BorderColor3 = Color3.fromRGB(60, 93, 221)
Frame.BorderSizePixel = 3
Frame.Draggable = true
Frame.Position = UDim2.new(0, 245, 0, 10)
Frame.Size = UDim2.new(0, 1050, 0, 150)
Frame.BackgroundTransparency = (0.6)
Frame.Visible = true

One.Name = "One"
One.Parent = Frame
One.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
One.BackgroundTransparency = 0.2
One.Position = UDim2.new(0, 0, 0, 0)
One.Size = UDim2.new(0, 150, 0, 50)
One.Font = Enum.Font.SourceSans
One.TextSize = 20
One.Text = "One / Uno"
One.TextColor3 = Color3.fromRGB(60, 93, 221)
One.TextSize = 20
One.TextWrapped = true

Two.Name = "Two"
Two.Parent = Frame
Two.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Two.BackgroundTransparency = 0.2
Two.Position = UDim2.new(0, 150, 0, 0)
Two.Size = UDim2.new(0, 150, 0, 50)
Two.Font = Enum.Font.SourceSans
Two.TextSize = 20
Two.Text = "Two / Dos"
Two.TextColor3 = Color3.fromRGB(60, 93, 221)
Two.TextSize = 20
Two.TextWrapped = true

Three.Name = "Three"
Three.Parent = Frame
Three.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Three.BackgroundTransparency = 0.2
Three.Position = UDim2.new(0, 300, 0, 0)
Three.Size = UDim2.new(0, 150, 0, 50)
Three.Font = Enum.Font.SourceSans
Three.TextSize = 20
Three.Text = "Three / Tres"
Three.TextColor3 = Color3.fromRGB(60, 93, 221)
Three.TextSize = 20
Three.TextWrapped = true

Four.Name = "Four"
Four.Parent = Frame
Four.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Four.BackgroundTransparency = 0.2
Four.Position = UDim2.new(0, 450, 0, 0)
Four.Size = UDim2.new(0, 150, 0, 50)
Four.Font = Enum.Font.SourceSans
Four.TextSize = 20
Four.Text = "Four / Cuatro"
Four.TextColor3 = Color3.fromRGB(60, 93, 221)
Four.TextSize = 20
Four.TextWrapped = true

Five.Name = "Five"
Five.Parent = Frame
Five.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Five.BackgroundTransparency = 0.2
Five.Position = UDim2.new(0, 600, 0, 0)
Five.Size = UDim2.new(0, 150, 0, 50)
Five.Font = Enum.Font.SourceSans
Five.TextSize = 20
Five.Text = "Five / Cinco"
Five.TextColor3 = Color3.fromRGB(60, 93, 221)
Five.TextSize = 20
Five.TextWrapped = true

Six.Name = "Six"
Six.Parent = Frame
Six.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Six.BackgroundTransparency = 0.2
Six.Position = UDim2.new(0, 750, 0, 0)
Six.Size = UDim2.new(0, 150, 0, 50)
Six.Font = Enum.Font.SourceSans
Six.TextSize = 20
Six.Text = "Six / Seis"
Six.TextColor3 = Color3.fromRGB(60, 93, 221)
Six.TextSize = 20
Six.TextWrapped = true

Seven.Name = "Seven"
Seven.Parent = Frame
Seven.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Seven.BackgroundTransparency = 0.2
Seven.Position = UDim2.new(0, 900, 0, 0)
Seven.Size = UDim2.new(0, 150, 0, 50)
Seven.Font = Enum.Font.SourceSans
Seven.TextSize = 20
Seven.Text = "Seven / Siete"
Seven.TextColor3 = Color3.fromRGB(60, 93, 221)
Seven.TextSize = 20
Seven.TextWrapped = true

Eight.Name = "Eight"
Eight.Parent = Frame
Eight.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Eight.BackgroundTransparency = 0.2
Eight.Position = UDim2.new(0, 0, 0, 50)
Eight.Size = UDim2.new(0, 150, 0, 50)
Eight.Font = Enum.Font.SourceSans
Eight.TextSize = 20
Eight.Text = "Eight / Ocho"
Eight.TextColor3 = Color3.fromRGB(60, 93, 221)
Eight.TextSize = 20
Eight.TextWrapped = true

Nine.Name = "Nine"
Nine.Parent = Frame
Nine.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Nine.BackgroundTransparency = 0.2
Nine.Position = UDim2.new(0, 150, 0, 50)
Nine.Size = UDim2.new(0, 150, 0, 50)
Nine.Font = Enum.Font.SourceSans
Nine.TextSize = 20
Nine.Text = "Nine / Nueve"
Nine.TextColor3 = Color3.fromRGB(60, 93, 221)
Nine.TextSize = 20
Nine.TextWrapped = true

Ten.Name = "Ten"
Ten.Parent = Frame
Ten.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Ten.BackgroundTransparency = 0.2
Ten.Position = UDim2.new(0, 300, 0, 50)
Ten.Size = UDim2.new(0, 150, 0, 50)
Ten.Font = Enum.Font.SourceSans
Ten.TextSize = 20
Ten.Text = "Ten / Diez"
Ten.TextColor3 = Color3.fromRGB(60, 93, 221)
Ten.TextSize = 20
Ten.TextWrapped = true

Eleven.Name = "Eleven"
Eleven.Parent = Frame
Eleven.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Eleven.BackgroundTransparency = 0.2
Eleven.Position = UDim2.new(0, 450, 0, 50)
Eleven.Size = UDim2.new(0, 150, 0, 50)
Eleven.Font = Enum.Font.SourceSans
Eleven.TextSize = 20
Eleven.Text = "Eleven / Once"
Eleven.TextColor3 = Color3.fromRGB(60, 93, 221)
Eleven.TextSize = 20
Eleven.TextWrapped = true

Twelve.Name = "Twelve"
Twelve.Parent = Frame
Twelve.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Twelve.BackgroundTransparency = 0.2
Twelve.Position = UDim2.new(0, 600, 0, 50)
Twelve.Size = UDim2.new(0, 150, 0, 50)
Twelve.Font = Enum.Font.SourceSans
Twelve.TextSize = 20
Twelve.Text = "Twelve / Doce"
Twelve.TextColor3 = Color3.fromRGB(60, 93, 221)
Twelve.TextSize = 20
Twelve.TextWrapped = true

ThirTeen.Name = "ThirTeen"
ThirTeen.Parent = Frame
ThirTeen.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
ThirTeen.BackgroundTransparency = 0.2
ThirTeen.Position = UDim2.new(0, 750, 0, 50)
ThirTeen.Size = UDim2.new(0, 150, 0, 50)
ThirTeen.Font = Enum.Font.SourceSans
ThirTeen.TextSize = 20
ThirTeen.Text = "Thirteen / Trece"
ThirTeen.TextColor3 = Color3.fromRGB(60, 93, 221)
ThirTeen.TextSize = 20
ThirTeen.TextWrapped = true

FourTeen.Name = "FourTeen"
FourTeen.Parent = Frame
FourTeen.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
FourTeen.BackgroundTransparency = 0.2
FourTeen.Position = UDim2.new(0, 900, 0, 50)
FourTeen.Size = UDim2.new(0, 150, 0, 50)
FourTeen.Font = Enum.Font.SourceSans
FourTeen.TextSize = 20
FourTeen.Text = "Fourteen / Catorce"
FourTeen.TextColor3 = Color3.fromRGB(60, 93, 221)
FourTeen.TextSize = 20
FourTeen.TextWrapped = true

FifTeen.Name = "FifTeen"
FifTeen.Parent = Frame
FifTeen.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
FifTeen.BackgroundTransparency = 0.2
FifTeen.Position = UDim2.new(0, 0, 0, 100)
FifTeen.Size = UDim2.new(0, 150, 0, 50)
FifTeen.Font = Enum.Font.SourceSans
FifTeen.TextSize = 20
FifTeen.Text = "Fifteen / Quince"
FifTeen.TextColor3 = Color3.fromRGB(60, 93, 221)
FifTeen.TextSize = 20
FifTeen.TextWrapped = true

SixTeen.Name = "SixTeen"
SixTeen.Parent = Frame
SixTeen.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
SixTeen.BackgroundTransparency = 0.2
SixTeen.Position = UDim2.new(0, 150, 0, 100)
SixTeen.Size = UDim2.new(0, 150, 0, 50)
SixTeen.Font = Enum.Font.SourceSans
SixTeen.TextSize = 20
SixTeen.Text = "Sixteen / Diecis�is"
SixTeen.TextColor3 = Color3.fromRGB(60, 93, 221)
SixTeen.TextSize = 20
SixTeen.TextWrapped = true

SevenTeen.Name = "SevenTeen"
SevenTeen.Parent = Frame
SevenTeen.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
SevenTeen.BackgroundTransparency = 0.2
SevenTeen.Position = UDim2.new(0, 300, 0, 100)
SevenTeen.Size = UDim2.new(0, 150, 0, 50)
SevenTeen.Font = Enum.Font.SourceSans
SevenTeen.TextSize = 20
SevenTeen.Text = "Seventeen / Diecisiete"
SevenTeen.TextColor3 = Color3.fromRGB(60, 93, 221)
SevenTeen.TextSize = 20
SevenTeen.TextWrapped = true

EighTeen.Name = "EighTeen"
EighTeen.Parent = Frame
EighTeen.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
EighTeen.BackgroundTransparency = 0.2
EighTeen.Position = UDim2.new(0, 450, 0, 100)
EighTeen.Size = UDim2.new(0, 150, 0, 50)
EighTeen.Font = Enum.Font.SourceSans
EighTeen.TextSize = 20
EighTeen.Text = "Eighteen / Dieciocho"
EighTeen.TextColor3 = Color3.fromRGB(60, 93, 221)
EighTeen.TextSize = 20
EighTeen.TextWrapped = true

NineTeen.Name = "NineTeen"
NineTeen.Parent = Frame
NineTeen.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
NineTeen.BackgroundTransparency = 0.2
NineTeen.Position = UDim2.new(0, 600, 0, 100)
NineTeen.Size = UDim2.new(0, 150, 0, 50)
NineTeen.Font = Enum.Font.SourceSans
NineTeen.TextSize = 20
NineTeen.Text = "Nineteen / Diecinueve"
NineTeen.TextColor3 = Color3.fromRGB(60, 93, 221)
NineTeen.TextSize = 20
NineTeen.TextWrapped = true

Credits.Name = "Credits"
Credits.Parent = Frame
Credits.BackgroundColor3 = Color3.fromRGB(20, 2, 11)
Credits.BackgroundTransparency = 0.2
Credits.Position = UDim2.new(0, 750, 0, 100)
Credits.Size = UDim2.new(0, 300, 0, 50)
Credits.Font = Enum.Font.SourceSans
Credits.TextSize = 20
Credits.Text = "Made By: Neglected @ v3rm"
Credits.TextColor3 = Color3.fromRGB(60, 93, 221)
Credits.TextSize = 25
Credits.TextWrapped = true

One.MouseButton1Down:connect(function()
   game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(10, 579.145386, -20.2521057, 1, 0, 0, 0, 1, 0, 0, 0, 1) + Vector3.new(3,0,0)
end)

Two.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(9.74269295, 811.351868, 123.610313, 1, 4.25031321e-05, 7.49703622e-06, 7.4954005e-06, -0.342094988, 0.939665377, 4.25034159e-05, -0.939665437, -0.342094958) + Vector3.new(3,0,0)
end)

Three.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(259.773193, 908.62561, 267.718384, 0.971069217, -0.0435189642, -0.234799594, 0.231154963, -0.0754760876, 0.969984949, -0.0599344969, -0.996197522, -0.0632328764) + Vector3.new(3,0,0)
end)

Four.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(249.253067, 1184.69116, 418.838104, 0.655881643, -0.717412114, -0.23481755, 0.110057652, -0.21686691, 0.969977379, -0.746797562, -0.662033796, -0.0632823184) + Vector3.new(3,0,0)
end)

Five.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(85.7325134, 1055.85791, 600.634216, 0.491250306, 0.864276886, -0.108160302, 0.572882116, -0.414140224, -0.70731461, -0.656109273, 0.285505384, -0.698575258) + Vector3.new(3,0,0)
end)

Six.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(-132.578644, 638.48407, 597.864319, 0.829062223, 0.262213886, -0.493865669, -0.537013888, 0.619487226, -0.572590232, 0.155805901, 0.739923954, 0.654403806) + Vector3.new(3,0,0)
end)

Seven.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(-696.467529, 771.616516, 331.566345, -0.515048325, 0.43112433, -0.740848899, 0.323196292, 0.898188829, 0.297995061, 0.793895125, -0.0859577656, -0.60194838) + Vector3.new(3,0,0)
end)

Eight.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(-265.812256, 1051.26428, -206.54892, 0.163764939, 0.981880128, 0.09535449, 0.74780637, -0.0605171137, -0.661153018, -0.643402398, 0.179580361, -0.744166851) + Vector3.new(3,0,0)
end)

Nine.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(-34.5995331, 1198.06006, -532.234558, 0.761281848, -0.627461553, 0.163529947, -0.510623455, -0.424684465, 0.747600734, -0.39964211, -0.652636945, -0.643701196) + Vector3.new(3,0,0)
end)

Ten.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(51.2091064, 914.042847, -656.590576, 0.626874149, 0.659767151, 0.414410532, 0.424770087, -0.735305309, 0.528106511, 0.653145611, -0.155027151, -0.741193235) + Vector3.new(3,0,0)
end)

Eleven.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(383.565613, 319.026886, -267.54834, 0.101158947, 0.950429797, -0.29402408, 0.775641918, 0.109730333, 0.621561706, 0.623014092, -0.290933937, -0.726092935) + Vector3.new(3,0,0)
end)

Twelve.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(602.659302, 542.114563, -9.76993275, -0.40710339, 0.457046658, 0.790806711, -0.650288582, 0.462952346, -0.602328658, -0.641398132, -0.759462595, 0.108742759) + Vector3.new(3,0,0)
end)

ThirTeen.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(434.976715, 727.635742, 687.201416, 0.783870816, 0.302533567, -0.542236269, 0.528665245, -0.783201158, 0.327275395, -0.325668275, -0.543203056, -0.773867369) + Vector3.new(3,0,0)
end)

FourTeen.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(-13.1365337, 312.309814, 274.737427, 0.196870402, 0.934049368, -0.29798305, -0.513926268, 0.35714379, 0.779954016, 0.834938347, -0.000408523541, 0.550343454) + Vector3.new(3,0,0)
end)

FifTeen.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(-765.22168, 336.84082, -150.406967, -0.17553705, 0.938292861, -0.297981858, -0.611444294, 0.133314103, 0.779976487, 0.771571577, 0.319114059, 0.550312281) + Vector3.new(3,0,0)
end)

SixTeen.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(-579.786926, 1045.96338, -623.940857, 0.539399385, -0.787561774, 0.29798457, -0.338076651, -0.52665627, -0.779959857, 0.771202028, 0.319968253, -0.550334334) + Vector3.new(3,0,0)
end)

SevenTeen.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(38.0897446, 1170.41687, -167.988342, -0.746319294, -0.00686179055, -0.665552795, -0.13722989, 0.980048835, 0.143778816, 0.651287675, 0.198638633, -0.732370853) + Vector3.new(3,0,0)
end)

EighTeen.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(851.788635, 1085.41016, -144.591324, 0.670530975, -0.68853581, 0.276236683, 0.0602513328, -0.320575178, -0.94530493, 0.739430904, 0.65049988, -0.173470363) + Vector3.new(3,0,0)
end)

NineTeen.MouseButton1Down:connect(function()
game.Players.LocalPlayer.Character.Head.CFrame = CFrame.new(1159.50598, 958.562134, -652.858521, -0.835383415, -0.162779361, -0.525020659, -0.287038088, 0.943756878, 0.164110824, 0.468778163, 0.287795246, -0.835122824) + Vector3.new(3,0,0)
end)