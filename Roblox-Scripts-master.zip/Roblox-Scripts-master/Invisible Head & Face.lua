getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Head
pushnumber 1
setfield -2 Transparency
pcall 1 0 0
settop 0
getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 Head
getfield -1 face
pushnumber 1
setfield -2 Transparency
pcall 1 0 0
settop 0