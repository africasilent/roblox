getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Data
getfield -1 zSoda
pushstring 5555555
setfield -2 Value
emptystack
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Data
getfield -1 zMeat
pushstring 5555555
setfield -2 Value
emptystack
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Data
getfield -1 zOrange
pushstring 5555555
setfield -2 Value
emptystack
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Data
getfield -1 zApple
pushstring 5555555
setfield -2 Value
emptystack
getglobal game
getfield -1 GetService
pushvalue -2
pushstring Players
pcall 2 1 0
getfield -1 LocalPlayer
getfield -1 Data
getfield -1 zSenzu
pushstring 5555555
setfield -2 Value
emptystack