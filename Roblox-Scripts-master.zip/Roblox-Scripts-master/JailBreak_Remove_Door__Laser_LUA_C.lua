getglobal game
getfield -1 Workspace
getfield -1 Doors
getfield -1 Destroy
pushvalue -2
pcall 1 0 0
emptystack
getglobal game
getfield -1 Workspace
getfield -1 Banks
getfield -1 Bank
getfield -1 Lasers
getfield -1 Destroy
pushvalue -2
pcall 1 0 0
emptystack