getglobal game
getfield -1 ReplicatedStorage
getfield -1 Events
getfield -1 EquipGear
getfield -1 FireServer
pushvalue -2
pushnumber 123456
pcall 2 1 0