while true do
game.StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, true)
wait()
game.StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.Chat, false)
wait()
end