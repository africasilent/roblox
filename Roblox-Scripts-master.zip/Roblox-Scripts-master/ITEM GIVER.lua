getglobal game
getfield -1 Workspace
getfield -1 Events
getfield -1 ItemPurchase
getfield -1 InvokeServer
pushvalue -2
pushnumber 0
pushstring YourItemHere
pushnumber 0
pcall 4 1 0