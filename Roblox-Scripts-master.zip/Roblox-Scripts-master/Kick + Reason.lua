getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Kick
pushvalue -2
pushstring your message goes here lol
pcall 2 0 0
emptystack