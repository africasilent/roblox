getglobal game
getfield -1 ReplicatedStorage
getfield -1 Events
getfield -1 BuyCar
getfield -1 FireServer
pushvalue -2
pushstring CarYouWant
pushnumber -999999 (You can place more than 9 if you want more money)
pcall 3 1 0



Cars:
FanclubCar
Comet
Commander
FourDoor
Rari
RegularCar
Roadster
Speedster
Ultimator
Zagani
FuturisticCar
ShadowCar
DanTDMCar
HalloweenCar
FourDoorConvertible