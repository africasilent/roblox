getglobal game
getfield -1 ReplicatedStorage
getfield -1 REvents
getfield -1 Internal
getfield -1 jxbf
getfield -1 InvokeServer
pushvalue -2
pcall 1 1 0