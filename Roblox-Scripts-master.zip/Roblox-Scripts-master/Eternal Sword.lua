getglobal game
getfield -1 ReplicatedStorage
getfield -1 Weapons
getfield -1 Secondary
getfield -1 EternalSword
getglobal game
getfield -1 ReplicatedStorage
getfield -1 Remotes
getfield -1 StoreEquip
getfield -1 InvokeServer
pushvalue -2
pushstring Secondary
pushvalue -8
pcall 3 0 0
emptystack