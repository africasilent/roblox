while wait() do
game:GetService("ReplicatedStorage").Remotes.CreateForceField:InvokeServer("true","💩")
end