getglobal game
getfield -1 Workspace
getfield -1 Jewelrys
getfield -1 Jewelry
getfield -1 FloorLasers
getfield -1 Destroy
pushvalue -2
pcall 1 0 0
emptystack