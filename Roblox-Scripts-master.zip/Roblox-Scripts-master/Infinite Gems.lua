getglobal workspace
getfield -1 Events
getfield -1 TycoonItems
getfield -1 PurchaseGemItem
getfield -1 InvokeServer
pushvalue -2
pushnumber -999999999
pushstring G6
pcall 3 1 0