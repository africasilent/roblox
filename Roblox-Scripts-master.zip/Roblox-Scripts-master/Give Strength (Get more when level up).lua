getglobal game
getfield -1 ReplicatedStorage
getfield -1 DataHandeling
getfield -1 Traffic
getfield -1 Execute
getfield -1 FireServer
pushvalue -2
pushnumber 3793863509
pushstring Standing Dumbell Curl
pushstring Standing Dumbell Curl
pushnumber 9999999
pcall 5 1 0
getglobal end