getglobal workspace
pushnumber 50
setfield -2 Gravity
emptystack