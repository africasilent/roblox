getglobal game
getfield -1 Workspace
getfield -1 RemoteFunctions
getfield -1 ChangeGemAmount
getfield -1 InvokeServer
pushvalue -2
pushstring Demonite
pushnumber -2000
pcall 3 1 0
getglobal game
getfield -1 Workspace
getfield -1 RemoteFunctions
getfield -1 ChangeGemAmount
getfield -1 InvokeServer
pushvalue -2
pushstring Spirit Shard
pushnumber -2000
pcall 3 1 0
getglobal game
getfield -1 Workspace
getfield -1 RemoteFunctions
getfield -1 ChangeGemAmount
getfield -1 InvokeServer
pushvalue -2
pushstring Mithril
pushnumber -2000
pcall 3 1 0
getglobal game
getfield -1 Workspace
getfield -1 RemoteFunctions
getfield -1 ChangeGemAmount
getfield -1 InvokeServer
pushvalue -2
pushstring Dragon Bone
pushnumber -2000
pcall 3 1 0
getglobal game
getfield -1 Workspace
getfield -1 RemoteFunctions
getfield -1 ChangeGemAmount
getfield -1 InvokeServer
pushvalue -2
pushstring Fury Stone
pushnumber -2000
pcall 3 1 0
getglobal game
getfield -1 Workspace
getfield -1 RemoteFunctions
getfield -1 ChangeGemAmount
getfield -1 InvokeServer
pushvalue -2
pushstring Red Diamond
pushnumber -2000
pcall 3 1 0
getglobal game
getfield -1 Workspace
getfield -1 RemoteFunctions
getfield -1 ChangeGemAmount
getfield -1 InvokeServer
pushvalue -2
pushstring Tanzanite
pushnumber -2000
pcall 3 1 0





