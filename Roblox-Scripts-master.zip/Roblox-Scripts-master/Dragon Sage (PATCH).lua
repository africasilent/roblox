getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Backpack
getfield -1 keyinput
getfield -1 FireServer
pushvalue -2
pushstring equipkey
pushstring mode
pushstring dragonsage
pcall 4 1 0
emptystack