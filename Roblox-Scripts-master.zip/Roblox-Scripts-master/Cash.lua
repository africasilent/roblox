getglobal game
getfield -1 Workspace
getfield -1 boughted
getfield -1 FireServer
pushvalue -2
pushstring spoilerbuy
pushnumber -20000000
pushnumber 1
pcall 4 1 0