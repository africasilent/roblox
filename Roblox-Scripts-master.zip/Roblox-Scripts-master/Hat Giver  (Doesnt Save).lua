getglobal game
getfield -1 Players
getfield -1 YourName
getfield -1 Pstats
getfield -1 Chars
getfield -1 Char1
getfield -1 Hat
pushstring (Hat Name Here)
getfield -1 Value