getglobal  game
getfield -1 ReplicatedStorage
getfield -1 Buy
getfield -1 FireServer
pushvalue -2
pushstring Cosmite
pushstring 1
pcall 3 1 0