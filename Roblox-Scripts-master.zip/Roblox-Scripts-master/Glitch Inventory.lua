while true do
game.StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, true)
wait()
game.StarterGui:SetCoreGuiEnabled(Enum.CoreGuiType.PlayerList, false)
wait()
end