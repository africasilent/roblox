getglobal game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 Character
getfield -1 HumanoidRootPart
getglobal CFrame
getfield -1 new
pushnumber 751.44
pushnumber 69.52
pushnumber 1124.96
pcall 3 1 0
setfield -3 CFrame