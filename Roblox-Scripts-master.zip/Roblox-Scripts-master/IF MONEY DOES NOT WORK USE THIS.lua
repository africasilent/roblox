getglobal game
getfield -1 ReplicatedStorage
getfield -1 Transactions
getfield -1 ClientToServer
getfield -1 AttemptPurchase
getfield -1 InvokeServer
pushvalue -2
pushnumber -10000000
pcall 2 1 0
getglobal  game
getfield -1 Players
getfield -1 LocalPlayer
getfield -1 PlayerGui
getfield -1 LoadSaveGUI
getfield -1 LoadSaveClient
getfield -1 SavePlease
getfield -1 Fire
pushvalue -2
pcall 1 1 0