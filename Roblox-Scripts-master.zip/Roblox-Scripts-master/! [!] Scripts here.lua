Go to the Furk SE folder, then open the "Scripts" folder and put
 your scripts into it